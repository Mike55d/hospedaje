<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_wdt']), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_search_results']), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler']), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_router']), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception']), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception_css']), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_twig_error_test']), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        elseif (0 === strpos($pathinfo, '/api')) {
            if (0 === strpos($pathinfo, '/api/calendario')) {
                // app_apicalendario_reservaciones
                if ('/api/calendario/reservaciones' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\ApiCalendarioController::reservacionesAction',  '_route' => 'app_apicalendario_reservaciones',);
                }

                // app_apicalendario_datosfiltro
                if ('/api/calendario/datosFiltro' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\ApiCalendarioController::datosFiltroAction',  '_route' => 'app_apicalendario_datosfiltro',);
                }

                // app_apicalendario_getfechareserva
                if ('/api/calendario/getFechaReserva' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\ApiCalendarioController::getFechaReserva',  '_route' => 'app_apicalendario_getfechareserva',);
                }

            }

            // serviciosUs
            if ('/api/serviciosUs/nuevo' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServiciosUsController::nuevoAction',  '_route' => 'serviciosUs',);
            }

            // serviciosUsDelete
            if ('/api/serviciosUs/del' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServiciosUsController::delAction',  '_route' => 'serviciosUsDelete',);
            }

            // getServicios
            if ('/api/getServicios' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServiciosUsController::getServiciosAction',  '_route' => 'getServicios',);
            }

        }

        elseif (0 === strpos($pathinfo, '/calendario')) {
            // calendario_index
            if ('/calendario' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\CalendarioController::indexAction',  '_route' => 'calendario_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_calendario_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'calendario_index'));
                }

                return $ret;
            }
            not_calendario_index:

            // calendario_newReserva
            if ('/calendario/newReserva' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\CalendarioController::newAction',  '_route' => 'calendario_newReserva',);
            }

            // calendario_editReserva
            if ('/calendario/editReserva' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\CalendarioController::editAction',  '_route' => 'calendario_editReserva',);
            }

            // calendario_delReserva
            if ('/calendario/delReserva' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\CalendarioController::delAction',  '_route' => 'calendario_delReserva',);
            }

        }

        // camas_index
        if (0 === strpos($pathinfo, '/camas') && preg_match('#^/camas/(?P<id>[^/]++)/camas$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, ['_route' => 'camas_index']), array (  '_controller' => 'AppBundle\\Controller\\CamasController::indexAction',));
        }

        // homepage
        if ('/dashboard' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // dash
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::dashboardAction',  '_route' => 'dash',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_dash;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'dash'));
            }

            return $ret;
        }
        not_dash:

        if (0 === strpos($pathinfo, '/faqs')) {
            // faqs_index
            if ('/faqs' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\FaqsController::indexAction',  '_route' => 'faqs_index',);
            }

            // faqs
            if ('/faqs/nuevo' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\FaqsController::nuevoAction',  '_route' => 'faqs',);
            }

            // edita_Faq
            if (0 === strpos($pathinfo, '/faqs/edita') && preg_match('#^/faqs/edita/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'edita_Faq']), array (  '_controller' => 'AppBundle\\Controller\\FaqsController::editaAction',));
            }

        }

        // elimina_faq
        if (0 === strpos($pathinfo, '/Faqs/elimina') && preg_match('#^/Faqs/elimina/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, ['_route' => 'elimina_faq']), array (  '_controller' => 'AppBundle\\Controller\\FaqsController::eliminaAction',));
        }

        if (0 === strpos($pathinfo, '/grupo')) {
            // grupo_index
            if ('/grupo' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\GrupoController::indexAction',  '_route' => 'grupo_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_grupo_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'grupo_index'));
                }

                return $ret;
            }
            not_grupo_index:

            // grupo_new
            if ('/grupo/new' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\GrupoController::newAction',  '_route' => 'grupo_new',);
            }

            // grupo_edit
            if (preg_match('#^/grupo(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'grupo_edit']), array (  '_controller' => 'AppBundle\\Controller\\GrupoController::editAction',));
            }

            // grupo_del
            if ('/grupo/del' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\GrupoController::delAction',  '_route' => 'grupo_del',);
            }

        }

        elseif (0 === strpos($pathinfo, '/miGrupo')) {
            // personas_index
            if ('/miGrupo' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\PersonasController::indexAction',  '_route' => 'personas_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_personas_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'personas_index'));
                }

                return $ret;
            }
            not_personas_index:

            // personas_new
            if ('/miGrupo/new' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\PersonasController::newAction',  '_route' => 'personas_new',);
            }

            // personas_edit
            if (preg_match('#^/miGrupo/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'personas_edit']), array (  '_controller' => 'AppBundle\\Controller\\PersonasController::editAction',));
            }

            // personas_del
            if (preg_match('#^/miGrupo/(?P<id>[^/]++)/del$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'personas_del']), array (  '_controller' => 'AppBundle\\Controller\\PersonasController::delAction',));
            }

            // personas_todas
            if ('/miGrupo/todas' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\PersonasController::personasAction',  '_route' => 'personas_todas',);
            }

            // personas_servicios
            if (preg_match('#^/miGrupo/(?P<id>[^/]++)/(?P<reserva>[^/]++)/personasServicios$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'personas_servicios']), array (  '_controller' => 'AppBundle\\Controller\\PersonasController::personasServiciosAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/reservas')) {
            // reservas_misReservas
            if ('/reservas/misReservas' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ReservasController::indexAction',  '_route' => 'reservas_misReservas',);
            }

            // reservas_admin
            if ('/reservas/reservasAdmin' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ReservasController::indexAdminAction',  '_route' => 'reservas_admin',);
            }

            // detallesReserva_admin
            if (preg_match('#^/reservas/(?P<id>[^/]++)/detallesReserva$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'detallesReserva_admin']), array (  '_controller' => 'AppBundle\\Controller\\ReservasController::detallesReservaAction',));
            }

            // reservas_new
            if (preg_match('#^/reservas/(?P<id>[^/]++)/new$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'reservas_new']), array (  '_controller' => 'AppBundle\\Controller\\ReservasController::newAction',));
            }

            // reservas_edit
            if ('/reservas/edit' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ReservasController::editAction',  '_route' => 'reservas_edit',);
            }

            // reservas_del
            if ('/reservas/del' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ReservasController::delAction',  '_route' => 'reservas_del',);
            }

            // reservas_comidas
            if ('/reservas/comidas' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ReservasController::comidasAction',  '_route' => 'reservas_comidas',);
            }

        }

        // login
        if ('/login' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\SecurityController::loginAction',  '_route' => 'login',);
        }

        if (0 === strpos($pathinfo, '/servicios')) {
            // index
            if ('/servicios' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServiciosController::indexAction',  '_route' => 'index',);
            }

            // servicios
            if ('/servicios/nuevo' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServiciosController::nuevoAction',  '_route' => 'servicios',);
            }

            // edita_servicio
            if (0 === strpos($pathinfo, '/servicios/edita') && preg_match('#^/servicios/edita/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'edita_servicio']), array (  '_controller' => 'AppBundle\\Controller\\ServiciosController::editaAction',));
            }

            // elimina_servicio
            if (0 === strpos($pathinfo, '/servicios/elimina') && preg_match('#^/servicios/elimina/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'elimina_servicio']), array (  '_controller' => 'AppBundle\\Controller\\ServiciosController::eliminaAction',));
            }

            // serviciosVer
            if (0 === strpos($pathinfo, '/servicios/ver') && preg_match('#^/servicios/ver/(?P<tipo>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'serviciosVer']), array (  '_controller' => 'AppBundle\\Controller\\ServiciosController::verAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/Solicitudes')) {
            // solicitudes_misSolicitudes
            if (preg_match('#^/Solicitudes/(?P<status>[^/]++)/misSolicitudes$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'solicitudes_misSolicitudes']), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesController::indexAction',));
            }

            // solicitudes_indexAdmin
            if (preg_match('#^/Solicitudes/(?P<status>[^/]++)/Solicitudes$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'solicitudes_indexAdmin']), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesController::indexAdminAction',));
            }

            // solicitudes_new
            if ('/Solicitudes/new' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\SolicitudesController::newAction',  '_route' => 'solicitudes_new',);
            }

            // solicitudes_changeStatus
            if (preg_match('#^/Solicitudes/(?P<id>[^/]++)/(?P<status>[^/]++)/(?P<statusRedirect>[^/]++)/changeStatus$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'solicitudes_changeStatus']), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesController::changeStatusAction',));
            }

            // solicitudes_changeStatusHome
            if (preg_match('#^/Solicitudes/(?P<id>[^/]++)/(?P<status>[^/]++)/changeStatus$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'solicitudes_changeStatusHome']), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesController::changeStatusHomeAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/users')) {
            // users_index
            if ('/users' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\UsersController::indexAction',  '_route' => 'users_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_users_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'users_index'));
                }

                return $ret;
            }
            not_users_index:

            // users_new
            if ('/users/new' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UsersController::newAction',  '_route' => 'users_new',);
            }

        }

        // users_edit
        if (preg_match('#^/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, ['_route' => 'users_edit']), array (  '_controller' => 'AppBundle\\Controller\\UsersController::editAction',));
        }

        // users_del
        if ('/users/del' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\UsersController::delAction',  '_route' => 'users_del',);
        }

        // users_all
        if ('/users/todos' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\UsersController::todosAction',  '_route' => 'users_all',);
        }

        // users_register
        if ('/register' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\UsersController::registerAction',  '_route' => 'users_register',);
        }

        // logout
        if ('/logout' === $pathinfo) {
            return ['_route' => 'logout'];
        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
