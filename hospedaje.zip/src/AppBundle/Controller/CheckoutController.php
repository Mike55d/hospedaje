<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

/**
	* @Route("/checkout")
	*/
class CheckoutController extends Controller
{
  /**
   * @Route("/")
   */
  public function indexAction()
  {
  	return $this->render('AppBundle:Checkout:index.html.twig', array(

  	));
  }

}
